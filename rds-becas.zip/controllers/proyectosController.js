
exports.proyectosHome = (req, res) => {
    res.render('index', {
        nombrePagina: "RDS-BECAS"
    });
}